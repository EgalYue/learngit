//
// Created by ubuntu on 18-5-15.
//

#ifndef REPO_CONTROL_H_ANIMAL_H
#define REPO_CONTROL_H_ANIMAL_H

#define VERSION @RELEASE_VERSION@

#include <iostream>

class Animal {
public:
    Animal();
    Animal(std::string kind);
    Animal(std::string kind, int age);

private:
    std::string kind_;
    int age_;
};


#endif //REPO_CONTROL_H_ANIMAL_H
