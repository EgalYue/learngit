//
// Created by ubuntu on 18-5-15.
//

#ifndef REPO_CONTROL_H_HUMAN_H
#define REPO_CONTROL_H_HUMAN_H

#define VERSION @RELEASE_VERSION@

#include <iostream>

class Human {
public:
    Human();
    Human(std::string name);
    Human(std::string name, int age);
    Human(std::string name, int age, bool sex);

private:
    std::string name_;
    int age_;
    bool sex_;
};


#endif //REPO_CONTROL_H_HUMAN_H
