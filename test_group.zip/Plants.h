//
// Created by ubuntu on 18-5-15.
//

#ifndef REPO_CONTROL_H_PLANTS_H
#define REPO_CONTROL_H_PLANTS_H

#define VERSION @RELEASE_VERSION@

#include <iostream>

class Plants {
public:
    Plants();
    Plants(std::string kind);
    Plants(std::string kind, int age);

private:
    std::string kind_;
    int age_;
};


#endif //REPO_CONTROL_H_PLANTS_H
